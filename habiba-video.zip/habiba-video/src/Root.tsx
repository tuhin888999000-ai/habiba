import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {FPS, TOTAL_SEC} from './data';

export const Root: React.FC = () => (
  <Composition
    id="HabibaVideo"
    component={Video}
    durationInFrames={Math.ceil(TOTAL_SEC * FPS)}
    fps={FPS}
    width={1920}
    height={1080}
  />
);
