import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';
import {FPS, SC, sec} from './data';
import {Caption} from './components/UI';
import {Scene1} from './scenes/Scene1';
import {Scene2} from './scenes/Scene2';
import {Scene3} from './scenes/Scene3';
import {Scene4} from './scenes/Scene4';
import {Scene5} from './scenes/Scene5';

const {fontFamily} = loadFont('normal', {weights: ['400', '600', '700'], subsets: ['bengali', 'latin']});

const Overlay: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  return <Caption t={t} />;
};

const scenes: [readonly [number, number], React.FC][] = [
  [SC.s1, Scene1],
  [SC.s2, Scene2],
  [SC.s3, Scene3],
  [SC.s4, Scene4],
  [SC.s5, Scene5],
];

export const Video: React.FC = () => (
  <AbsoluteFill style={{fontFamily, background: '#000'}}>
    <Audio src={staticFile('voice.mp3')} />
    {scenes.map(([r, C], i) => (
      <Sequence key={i} from={sec(r[0])} durationInFrames={sec(r[1]) - sec(r[0])}>
        <C />
      </Sequence>
    ))}
    <AbsoluteFill style={{pointerEvents: 'none', background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 60%, rgba(0,0,0,0.16) 100%)'}} />
    <Overlay />
  </AbsoluteFill>
);
