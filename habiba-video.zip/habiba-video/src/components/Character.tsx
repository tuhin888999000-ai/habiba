import React from 'react';
import {useCurrentFrame} from 'remotion';

export type Expr = 'happy' | 'smile' | 'sleepy' | 'angry' | 'sad' | 'cry' | 'worried' | 'tired' | 'surprised';
export type Who = 'habiba' | 'ammu';
export type Hair = 'bun' | 'loose' | 'pigtails';
export type Outfit = 'home' | 'school' | 'saree';

const O = '#222222';
const HAIR = '#1c1c1c';
const SKIN: Record<Who, string> = {habiba: '#EFBE92', ammu: '#C98F5E'};

const Limb: React.FC<{x1: number; y1: number; x2: number; y2: number; w: number; fill: string}> = ({x1, y1, x2, y2, w, fill}) => (
  <g strokeLinecap="round">
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={O} strokeWidth={w + 6} />
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={fill} strokeWidth={w} />
  </g>
);

const defHair = (who: Who): Hair => (who === 'habiba' ? 'pigtails' : 'bun');

export const HairBack: React.FC<{who: Who; hair?: Hair}> = ({who, hair}) => {
  const h = hair ?? defHair(who);
  return (
    <g fill={HAIR} stroke={O} strokeWidth={3} strokeLinejoin="round">
      {h === 'loose' && <path d="M80,100 Q52,230 88,266 L212,266 Q248,230 220,100 Z" />}
      {h === 'pigtails' && (
        <>
          <path d="M84,104 Q64,196 96,210 L204,210 Q236,196 216,104 Z" />
          <circle cx={80} cy={58} r={19} />
          <circle cx={220} cy={58} r={19} />
        </>
      )}
      {h === 'bun' && (
        <>
          <ellipse cx={150} cy={112} rx={68} ry={72} />
          <circle cx={98} cy={178} r={24} />
        </>
      )}
    </g>
  );
};

export const Head: React.FC<{who: Who; expr: Expr; talking?: boolean; hair?: Hair}> = ({who, expr, talking = false}) => {
  const f = useCurrentFrame();
  const skin = SKIN[who];
  const bp = f % 100;
  const open = bp < 5 ? Math.max(0.08, Math.abs(bp - 2.5) / 2.5) : 1;
  const m = talking ? [0, 1, 2, 1, 0, 2, 1, 2][Math.floor(f / 3) % 8] : 0;
  const eyeRy = expr === 'surprised' ? 18 : expr === 'tired' ? 9 : expr === 'angry' ? 11 : 14;
  const dy = ['sad', 'cry', 'worried', 'tired'].includes(expr) ? 3 : 0;
  const BR: Record<Expr, [number, number]> = {
    happy: [96, 93], smile: [94, 92], sleepy: [98, 98], angry: [88, 101], sad: [99, 88],
    cry: [99, 87], worried: [98, 87], tired: [98, 94], surprised: [80, 80],
  };
  const [oy, iy] = BR[expr];
  const cyb = (oy + iy) / 2 - (expr === 'angry' ? 0 : 5);

  const eye = (cx: number) => {
    if (expr === 'sleepy')
      return <path key={cx} d={`M${cx - 14},114 Q${cx},126 ${cx + 14},114`} fill="none" stroke={O} strokeWidth={4} strokeLinecap="round" />;
    if (expr === 'smile')
      return <path key={cx} d={`M${cx - 14},122 Q${cx},106 ${cx + 14},122`} fill="none" stroke={O} strokeWidth={4} strokeLinecap="round" />;
    return (
      <g key={cx}>
        <g transform={`translate(0,118) scale(1,${open}) translate(0,-118)`}>
          <ellipse cx={cx} cy={118} rx={13} ry={eyeRy} fill="#fff" stroke={O} strokeWidth={2.5} />
          <circle cx={cx} cy={118 + dy} r={expr === 'surprised' ? 6 : 8.5} fill="#6B3A1E" />
          <circle cx={cx} cy={118 + dy} r={4} fill={O} />
          <circle cx={cx + 3} cy={114 + dy} r={2.2} fill="#fff" />
        </g>
        {expr === 'tired' && <path d={`M${cx - 10},134 Q${cx},139 ${cx + 10},134`} fill="none" stroke="#8a5a3a" strokeWidth={2.5} />}
      </g>
    );
  };

  const closed = () => {
    switch (expr) {
      case 'smile': return <path d="M126,146 Q150,178 174,146 Z" fill="#B23A3A" />;
      case 'sleepy': return <ellipse cx={150} cy={154} rx={6} ry={4} fill="#B23A3A" />;
      case 'angry': return <path d="M132,160 Q150,146 168,160" />;
      case 'sad':
      case 'cry': return <path d="M130,162 Q150,146 170,162" />;
      case 'worried': return <path d="M130,157 Q140,150 150,157 T170,157" />;
      case 'tired': return <path d="M136,155 Q150,163 164,155" />;
      case 'surprised': return <ellipse cx={150} cy={157} rx={8} ry={11} fill="#8E2B2B" />;
      default: return <path d="M132,148 Q150,166 168,148" />;
    }
  };

  const brow = (ox: number, ix: number) => (
    <path d={`M${ox},${oy} Q${(ox + ix) / 2},${cyb} ${ix},${iy}`} fill="none" stroke={O} strokeWidth={4.5} strokeLinecap="round" />
  );

  return (
    <g strokeLinejoin="round">
      <circle cx={88} cy={124} r={11} fill={skin} stroke={O} strokeWidth={3} />
      <circle cx={212} cy={124} r={11} fill={skin} stroke={O} strokeWidth={3} />
      <ellipse cx={150} cy={120} rx={62} ry={66} fill={skin} stroke={O} strokeWidth={3} />
      {who === 'habiba' ? (
        <path d="M85,122 Q80,44 150,42 Q220,44 215,122 Q196,72 150,90 Q104,72 85,122Z" fill={HAIR} stroke={O} strokeWidth={3} />
      ) : (
        <path d="M85,122 Q80,44 150,42 Q220,44 215,122 Q202,80 150,74 Q98,80 85,122Z" fill={HAIR} stroke={O} strokeWidth={3} />
      )}
      {who === 'ammu' && <circle cx={150} cy={92} r={4.5} fill={O} />}
      <circle cx={110} cy={142} r={11} fill={expr === 'angry' ? '#E24B4B' : '#F08A8A'} opacity={expr === 'angry' ? 0.55 : 0.35} />
      <circle cx={190} cy={142} r={11} fill={expr === 'angry' ? '#E24B4B' : '#F08A8A'} opacity={expr === 'angry' ? 0.55 : 0.35} />
      {brow(106, 140)}
      {brow(194, 160)}
      {eye(125)}
      {eye(175)}
      <path d="M146,137 Q150,142 154,137" fill="none" stroke="#7a4a2a" strokeWidth={2.5} strokeLinecap="round" />
      <g fill="none" stroke={O} strokeWidth={4} strokeLinecap="round">
        {m === 1 ? (
          <ellipse cx={150} cy={154} rx={10} ry={6} fill="#8E2B2B" strokeWidth={3} />
        ) : m === 2 ? (
          <g>
            <ellipse cx={150} cy={157} rx={13} ry={13} fill="#8E2B2B" strokeWidth={3} />
            <ellipse cx={150} cy={165} rx={8} ry={5} fill="#E57373" stroke="none" />
          </g>
        ) : (
          closed()
        )}
      </g>
      {expr === 'cry' &&
        [125, 175].map((cx, i) => {
          const p = ((f * 3 + i * 25) % 60) / 60;
          return <ellipse key={cx} cx={cx + (i ? 3 : -3)} cy={132 + p * 40} rx={5} ry={8} fill="#6EC6FF" stroke={O} strokeWidth={2} opacity={1 - p * 0.8} />;
        })}
      {who === 'habiba' &&
        [88, 212].map((x) => (
          <g key={x} transform={`translate(${x},72)`} fill="#E5303A" stroke={O} strokeWidth={2.5}>
            <path d="M-14,-8 L0,0 L-14,8Z M14,-8 L0,0 L14,8Z" />
            <circle r={4} />
          </g>
        ))}
    </g>
  );
};

const Arm: React.FC<{sx: number; angle: number; skin: string; sleeve: {c: string; l: number}; children?: React.ReactNode}> = ({sx, angle, skin, sleeve, children}) => {
  const len = 90;
  return (
    <g transform={`translate(${sx},216) rotate(${angle})`}>
      <Limb x1={0} y1={0} x2={0} y2={len} w={18} fill={skin} />
      <Limb x1={0} y1={0} x2={0} y2={sleeve.l} w={24} fill={sleeve.c} />
      <circle cx={0} cy={len} r={11} fill={skin} stroke={O} strokeWidth={3} />
      {children && <g transform={`translate(0,${len}) rotate(${-angle})`}>{children}</g>}
    </g>
  );
};

type CharProps = {
  who: Who; outfit?: Outfit; expr?: Expr; talking?: boolean; x: number; floorY: number; scale: number;
  aL?: number; aR?: number; walk?: number; hair?: Hair; holdL?: React.ReactNode; holdR?: React.ReactNode;
  tremble?: number; bob?: boolean;
};

export const Character: React.FC<CharProps> = ({
  who, outfit, expr = 'happy', talking = false, x, floorY, scale, aL = 10, aR = 10, walk, hair, holdL, holdR, tremble = 0, bob = true,
}) => {
  const f = useCurrentFrame();
  const of: Outfit = outfit ?? (who === 'ammu' ? 'saree' : 'home');
  const skin = SKIN[who];
  const W = 300, H = 470;
  const by = bob ? Math.sin(f / 10) * 4 : 0;
  const jx = tremble ? Math.sin(f * 2.7) * tremble : 0;
  const sw = walk === undefined ? 0 : Math.sin(walk) * 24;
  const sl = of === 'home' ? {c: '#FFD23F', l: 26} : of === 'school' ? {c: '#FFFFFF', l: 52} : {c: '#F4A6B8', l: 36};
  return (
    <div style={{position: 'absolute', left: x - (W * scale) / 2 + jx, top: floorY - H * scale + by, width: W * scale, height: H * scale}}>
      <svg viewBox={`0 0 ${W} ${H}`} width={W * scale} height={H * scale} style={{overflow: 'visible'}}>
        <HairBack who={who} hair={hair} />
        {of === 'school' && <rect x={86} y={208} width={128} height={118} rx={28} fill="#2F6FDE" stroke={O} strokeWidth={3} />}
        {who === 'habiba' &&
          [[128, sw], [172, -sw]].map(([lx, a], i) => (
            <g key={i} transform={`rotate(${a},${lx},322)`}>
              <Limb x1={lx} y1={322} x2={lx} y2={420} w={20} fill={of === 'school' ? '#F2F2F2' : skin} />
              <ellipse cx={lx} cy={428} rx={21} ry={10} fill="#222" stroke={O} strokeWidth={3} />
            </g>
          ))}
        {who === 'ammu' && [130, 170].map((fx) => <ellipse key={fx} cx={fx} cy={456} rx={20} ry={9} fill={skin} stroke={O} strokeWidth={3} />)}
        {of === 'home' && (
          <g>
            <path d="M104,196 Q150,186 196,196 L224,338 Q150,354 76,338 Z" fill="#FFD23F" stroke={O} strokeWidth={3} strokeLinejoin="round" />
            {[[118, 280], [160, 305], [192, 268], [135, 230]].map(([cx, cy]) => <circle key={cx} cx={cx} cy={cy} r={5} fill="#fff" />)}
          </g>
        )}
        {of === 'school' && (
          <g strokeLinejoin="round">
            <path d="M104,196 Q150,186 196,196 L214,354 Q150,366 86,354 Z" fill="#fff" stroke={O} strokeWidth={3} />
            <path d="M106,198 L136,192 L206,346 L172,358 Z" fill="#3B82F6" stroke={O} strokeWidth={3} />
            <line x1={120} y1={196} x2={124} y2={300} stroke={O} strokeWidth={14} strokeLinecap="round" />
            <line x1={120} y1={196} x2={124} y2={300} stroke="#2F6FDE" strokeWidth={8} strokeLinecap="round" />
            <line x1={180} y1={196} x2={176} y2={300} stroke={O} strokeWidth={14} strokeLinecap="round" />
            <line x1={180} y1={196} x2={176} y2={300} stroke="#2F6FDE" strokeWidth={8} strokeLinecap="round" />
          </g>
        )}
        {of === 'saree' && (
          <g strokeLinejoin="round">
            <path d="M102,196 Q150,186 198,196 L230,440 Q150,458 70,440 Z" fill="#2E9E5B" stroke={O} strokeWidth={3} />
            <path d="M104,198 L140,192 L216,420 L170,446 Z" fill="#1F7A43" stroke={O} strokeWidth={3} />
            <path d="M72,430 Q150,448 228,430 L230,440 Q150,458 70,440Z" fill="#F2C14E" stroke={O} strokeWidth={2} />
          </g>
        )}
        <rect x={136} y={176} width={28} height={30} rx={8} fill={skin} stroke={O} strokeWidth={3} />
        <Arm sx={102} angle={aL} skin={skin} sleeve={sl}>{holdL}</Arm>
        <Arm sx={198} angle={-aR} skin={skin} sleeve={sl}>{holdR}</Arm>
        <Head who={who} expr={expr} talking={talking} hair={hair} />
      </svg>
    </div>
  );
};

// বিছানায় শুয়ে থাকা অবস্থার জন্য শুধু মাথা (x,y = মাথার কেন্দ্র, w = বক্সের প্রস্থ)
export const HeadOnly: React.FC<{who: Who; expr: Expr; talking?: boolean; hair?: Hair; x: number; y: number; w: number; rot?: number}> = ({who, expr, talking, hair, x, y, w, rot = 0}) => (
  <div style={{position: 'absolute', left: x - w / 2, top: y - w * 0.38, width: w, height: w, transform: `rotate(${rot}deg)`}}>
    <svg viewBox="25 25 250 250" width={w} height={w} style={{overflow: 'visible'}}>
      <HairBack who={who} hair={hair} />
      <Head who={who} expr={expr} talking={talking} hair={hair} />
    </svg>
  </div>
);
