import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';

const O = '#222222';

export const Room: React.FC<{wall: string; floor: string; floorY: number; children?: React.ReactNode}> = ({wall, floor, floorY, children}) => (
  <AbsoluteFill style={{background: wall}}>
    <div style={{position: 'absolute', left: 0, right: 0, top: floorY - 26, height: 26, background: 'rgba(0,0,0,0.08)'}} />
    <div style={{position: 'absolute', left: 0, right: 0, top: floorY, bottom: 0, background: `repeating-linear-gradient(90deg, ${floor} 0px, ${floor} 180px, rgba(0,0,0,.1) 180px, rgba(0,0,0,.1) 184px)`, borderTop: `6px solid ${O}`}} />
    {children}
  </AbsoluteFill>
);

export const Win: React.FC<{x: number; y: number; w: number; h: number; dusk?: boolean}> = ({x, y, w, h, dusk}) => {
  const f = useCurrentFrame();
  return (
    <svg style={{position: 'absolute', left: x, top: y}} width={w} height={h} viewBox="0 0 400 320">
      <rect width={400} height={320} fill={dusk ? '#FFA36B' : '#A9E0FF'} />
      <g transform={`translate(${dusk ? 290 : 310},${dusk ? 190 : 80})`}>
        {!dusk && [...Array(8)].map((_, i) => <line key={i} x1={0} y1={-52} x2={0} y2={-66} stroke="#FFB300" strokeWidth={7} strokeLinecap="round" transform={`rotate(${i * 45 + f * 0.6})`} />)}
        <circle r={38} fill={dusk ? '#FF6B35' : '#FFD23F'} />
      </g>
      <ellipse cx={(f * 0.4) % 500 - 50} cy={60} rx={50} ry={20} fill="#fff" opacity={dusk ? 0.4 : 0.9} />
      <path d="M0,230 Q100,170 200,225 T400,205 L400,320 L0,320Z" fill={dusk ? '#3F8F5A' : '#7CCB6B'} />
      <rect x={70} y={170} width={14} height={60} fill="#7B4B2A" />
      <circle cx={77} cy={160} r={40} fill={dusk ? '#2F7A49' : '#4CAF50'} />
      <line x1={200} y1={0} x2={200} y2={320} stroke="#8B5E3C" strokeWidth={10} />
      <line x1={0} y1={160} x2={400} y2={160} stroke="#8B5E3C" strokeWidth={10} />
      <rect x={4} y={4} width={392} height={312} fill="none" stroke="#8B5E3C" strokeWidth={14} />
      <rect x={-3} y={-3} width={406} height={326} fill="none" stroke={O} strokeWidth={4} />
    </svg>
  );
};

export const bedTop = (floorY: number) => floorY - 230;

export const BedBack: React.FC<{x: number; floorY: number; w: number}> = ({x, floorY, w}) => {
  const top = bedTop(floorY);
  return (
    <svg style={{position: 'absolute', left: 0, top: 0}} width={1920} height={1080}>
      <g stroke={O} strokeWidth={4}>
        <rect x={x} y={floorY - 400} width={46} height={400} rx={14} fill="#9B6A3F" />
        <rect x={x + 30} y={top} width={w - 30} height={64} rx={18} fill="#FAFAFA" />
        <rect x={x + 70} y={top - 50} width={200} height={64} rx={30} fill="#fff" />
      </g>
    </svg>
  );
};

// বিছানার সামনের কাঠ + কম্বল (ক্যারেক্টারের নিচের অংশ ঢাকে)
export const BedFront: React.FC<{x: number; floorY: number; w: number; bx: number; lift?: number; color: string}> = ({x, floorY, w, bx, lift = 0, color}) => {
  const top = bedTop(floorY);
  const by = top + 5 - lift;
  return (
    <svg style={{position: 'absolute', left: 0, top: 0}} width={1920} height={1080}>
      <g stroke={O} strokeWidth={4}>
        <rect x={x + 34} y={floorY - 40} width={30} height={40} fill="#7A4E2B" />
        <rect x={x + w - 64} y={floorY - 40} width={30} height={40} fill="#7A4E2B" />
        <rect x={x + 30} y={top + 64} width={w - 30} height={132} rx={10} fill="#B77B45" />
        <rect x={bx} y={by} width={x + w - 6 - bx} height={100 + lift} rx={36} fill={color} />
        <line x1={bx + 30} y1={by + 26} x2={x + w - 40} y2={by + 26} stroke="#fff" strokeWidth={6} opacity={0.7} />
      </g>
    </svg>
  );
};
