import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame} from 'remotion';
import {BubbleData, CAPS, FPS, textBusy} from '../data';

const O = '#222222';
export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
export const useScene = (start: number) => {
  const f = useCurrentFrame();
  return {f, t: f / FPS + start};
};
export const pop = (t: number, start: number, damping = 11) =>
  spring({frame: Math.max(0, (t - start) * FPS), fps: FPS, config: {damping, stiffness: 170}});
export const fadeOut = (t: number, end: number) => interpolate(t, [end - 0.12, end], [1, 0], clamp);
export const isHl = (w: string, hl: string) => hl.split('|').includes(w.replace(/[,।!?]/g, ''));

// দৃশ্যের ফেড, ঝাঁকুনি ও জুম
export const SceneFx: React.FC<{dur: number; shake?: number; zoom?: [number, number]; origin?: string; children: React.ReactNode}> = ({dur, shake = 0, zoom, origin = '50% 50%', children}) => {
  const f = useCurrentFrame();
  const o = Math.min(interpolate(f, [0, 10], [0, 1], clamp), interpolate(f, [dur - 8, dur], [1, 0], clamp));
  const z = (zoom ? interpolate(f, [0, dur], zoom) : 1) * (shake ? 1.02 : 1);
  const sx = shake ? Math.sin(f * 1.9) * shake : 0;
  const sy = shake ? Math.cos(f * 2.3) * shake : 0;
  return (
    <AbsoluteFill style={{opacity: o, background: '#000'}}>
      <AbsoluteFill style={{transform: `translate(${sx}px,${sy}px) scale(${z})`, transformOrigin: origin}}>{children}</AbsoluteFill>
    </AbsoluteFill>
  );
};

export type IconName = 'sun' | 'zzz' | 'clock' | 'burger' | 'plate' | 'anger' | 'heart' | 'brokenHeart' | 'thermo' | 'cross' | 'crown' | 'star' | 'tear' | 'question' | 'coin';

export const Icon: React.FC<{name: IconName; size?: number; rot?: number}> = ({name, size = 100, rot = 0}) => {
  const s = {stroke: O, strokeWidth: 4, strokeLinejoin: 'round' as const};
  const heart = 'M50,86 C8,56 4,26 26,17 C38,12 48,20 50,28 C52,20 62,12 74,17 C96,26 92,56 50,86Z';
  let body: React.ReactNode = null;
  switch (name) {
    case 'sun':
      body = (
        <g>
          {[...Array(8)].map((_, i) => <line key={i} x1={50} y1={8} x2={50} y2={20} stroke="#FFB300" strokeWidth={7} strokeLinecap="round" transform={`rotate(${i * 45} 50 50)`} />)}
          <circle cx={50} cy={50} r={24} fill="#FFD23F" {...s} />
        </g>
      );
      break;
    case 'zzz':
      body = (
        <g fill="#4A6FE3" stroke={O} strokeWidth={2.5} fontWeight={700}>
          <text x={6} y={92} fontSize={52}>Z</text>
          <text x={42} y={60} fontSize={38}>Z</text>
          <text x={68} y={34} fontSize={28}>z</text>
        </g>
      );
      break;
    case 'clock':
      body = (
        <g>
          <circle cx={50} cy={50} r={40} fill="#fff" {...s} strokeWidth={5} />
          {[0, 90, 180, 270].map((a) => <line key={a} x1={50} y1={14} x2={50} y2={22} stroke={O} strokeWidth={4} transform={`rotate(${a} 50 50)`} />)}
          <line x1={50} y1={50} x2={50} y2={30} stroke={O} strokeWidth={6} strokeLinecap="round" transform={`rotate(${rot / 12} 50 50)`} />
          <line x1={50} y1={50} x2={50} y2={18} stroke="#E63946" strokeWidth={4} strokeLinecap="round" transform={`rotate(${rot} 50 50)`} />
          <circle cx={50} cy={50} r={4} fill={O} />
        </g>
      );
      break;
    case 'burger':
      body = (
        <g {...s} strokeWidth={3.5}>
          <path d="M14,46 Q14,12 50,12 Q86,12 86,46 Z" fill="#E9A23B" />
          <path d="M10,50 Q22,40 34,50 T58,50 T90,50 L90,57 L10,57Z" fill="#6CC24A" />
          <rect x={14} y={57} width={72} height={14} rx={7} fill="#7B4B2A" />
          <path d="M14,73 H86 Q86,90 70,90 H30 Q14,90 14,73Z" fill="#E9A23B" />
        </g>
      );
      break;
    case 'plate':
      body = (
        <g {...s} strokeWidth={3.5}>
          <ellipse cx={50} cy={66} rx={44} ry={16} fill="#fff" />
          <path d="M22,62 Q40,20 62,62Z" fill="#fff" />
          <ellipse cx={68} cy={58} rx={22} ry={10} fill="#E9742B" />
        </g>
      );
      break;
    case 'anger':
      body = <path d="M18,36 Q36,36 36,18 M64,18 Q64,36 82,36 M82,64 Q64,64 64,82 M36,82 Q36,64 18,64" fill="none" stroke="#E63946" strokeWidth={10} strokeLinecap="round" />;
      break;
    case 'heart':
      body = (
        <g>
          <path d={heart} fill="#FF4D6D" {...s} />
          <path d="M26,34 Q30,26 38,28" fill="none" stroke="#fff" strokeWidth={5} strokeLinecap="round" opacity={0.7} />
        </g>
      );
      break;
    case 'brokenHeart':
      body = (
        <g>
          <path d={heart} fill="#FF4D6D" {...s} />
          <path d="M54,18 L44,42 L60,52 L46,86" fill="none" stroke="#fff" strokeWidth={9} strokeLinejoin="round" />
          <path d="M54,18 L44,42 L60,52 L46,86" fill="none" stroke={O} strokeWidth={3} strokeLinejoin="round" />
        </g>
      );
      break;
    case 'thermo':
      body = (
        <g {...s}>
          <rect x={40} y={8} width={20} height={64} rx={10} fill="#fff" />
          <circle cx={50} cy={78} r={16} fill="#E63946" />
          <line x1={50} y1={30} x2={50} y2={72} stroke="#E63946" strokeWidth={7} strokeLinecap="round" />
        </g>
      );
      break;
    case 'cross':
      body = (
        <g {...s}>
          <rect x={12} y={12} width={76} height={76} rx={18} fill="#fff" />
          <path d="M42,24 H58 V42 H76 V58 H58 V76 H42 V58 H24 V42 H42Z" fill="#E63946" strokeWidth={3} />
        </g>
      );
      break;
    case 'crown':
      body = <path d="M12,74 L8,30 L34,50 L50,20 L66,50 L92,30 L88,74 Z" fill="#FFC93C" {...s} />;
      break;
    case 'star':
      body = <polygon points="50,8 61,38 93,38 67,57 77,89 50,70 23,89 33,57 7,38 39,38" fill="#FFD23F" {...s} />;
      break;
    case 'tear':
      body = <path d="M50,10 Q82,52 50,88 Q18,52 50,10Z" fill="#6EC6FF" {...s} />;
      break;
    case 'question':
      body = <text x={50} y={86} fontSize={96} fontWeight={700} textAnchor="middle" fill="#4A6FE3" stroke={O} strokeWidth={3}>?</text>;
      break;
    case 'coin':
      body = (
        <g>
          <circle cx={50} cy={50} r={38} fill="#FFC93C" {...s} />
          <circle cx={50} cy={50} r={28} fill="none" stroke="#C9A227" strokeWidth={4} />
          <text x={50} y={62} fontSize={34} fontWeight={700} textAnchor="middle" fill="#8a6a00">৳</text>
        </g>
      );
      break;
  }
  return <svg viewBox="0 0 100 100" width={size} height={size} style={{overflow: 'visible'}}>{body}</svg>;
};

export const FloatIcon: React.FC<{name: IconName; x: number; y: number; size?: number; t: number; start: number; end: number; anim?: 'pop' | 'float' | 'pulse' | 'shake'}> = ({name, x, y, size = 120, t, start, end, anim = 'pop'}) => {
  const f = useCurrentFrame();
  if (t < start || t > end) return null;
  const p = pop(t, start);
  const dy = anim === 'float' ? Math.sin(f / 9) * 14 : 0;
  const sc = p * (anim === 'pulse' ? 1 + 0.1 * Math.sin(f / 4) : 1);
  const rot = anim === 'shake' ? Math.sin(f * 1.3) * 10 : 0;
  return (
    <div style={{position: 'absolute', left: x - size / 2, top: y - size / 2 + dy, width: size, height: size, opacity: fadeOut(t, end), transform: `scale(${sc}) rotate(${rot}deg)`}}>
      <Icon name={name} size={size} />
    </div>
  );
};

export const Pill: React.FC<{text: string; t: number; start: number; end: number; top: number; left?: number; cx?: number; bg?: string; size?: number}> = ({text, t, start, end, top, left = 60, cx, bg = '#FF7A45', size = 40}) => {
  if (t < start || t > end) return null;
  const p = pop(t, start, 14);
  const pos = cx !== undefined ? {left: cx, transform: `translateX(-50%) scale(${p})`} : {left, transform: `scale(${p})`, transformOrigin: 'left center'};
  return (
    <div style={{position: 'absolute', top, ...pos, opacity: fadeOut(t, end), background: bg, color: '#fff', fontWeight: 700, fontSize: size, padding: '8px 30px', borderRadius: 60, border: `4px solid ${O}`, whiteSpace: 'nowrap', boxShadow: '0 6px 0 rgba(0,0,0,.2)'}}>
      {text}
    </div>
  );
};

// স্পিচ কলআউট বাবল — (x, y) = লেজের ডগার অবস্থান; tail = বাবলের কেন্দ্র থেকে লেজের সরণ
export const Bubble: React.FC<{b: BubbleData; t: number; x: number; y: number; w?: number; tail?: number}> = ({b, t, x, y, w = 760, tail = 0}) => {
  if (t < b.start - 0.05 || t >= b.end + 0.1) return null;
  const s = pop(t, b.start - 0.05, 12);
  const o = interpolate(t, [b.end - 0.05, b.end + 0.1], [1, 0], clamp);
  const col = b.who === 'habiba' ? '#FF6FA5' : '#2E9E5B';
  const name = b.who === 'habiba' ? 'হাবিবা' : 'আম্মু';
  return (
    <div style={{position: 'absolute', left: x - w / 2, top: y, width: w, boxSizing: 'border-box', opacity: o, transform: `translateY(-100%) scale(${s})`, transformOrigin: `${w / 2 + tail}px 100%`, background: '#fff', border: `5px solid ${O}`, borderRadius: 38, padding: '34px 36px 26px', fontSize: 46, fontWeight: 600, lineHeight: 1.3, color: O, textAlign: 'center', boxShadow: '0 8px 0 rgba(0,0,0,.15)'}}>
      <div style={{position: 'absolute', top: -26, left: 28, background: col, color: '#fff', fontSize: 28, fontWeight: 700, padding: '2px 22px', borderRadius: 30, border: `4px solid ${O}`}}>{name}</div>
      {b.text}
      <div style={{position: 'absolute', bottom: -23, left: w / 2 + tail - 20, width: 38, height: 38, background: '#fff', borderRight: `5px solid ${O}`, borderBottom: `5px solid ${O}`, transform: 'rotate(45deg)'}} />
    </div>
  );
};

// থট বাবল (ভেতরে আইকন)
export const Thought: React.FC<{x: number; y: number; tx: number; ty: number; t: number; start: number; end: number; children: React.ReactNode}> = ({x, y, tx, ty, t, start, end, children}) => {
  if (t < start || t > end) return null;
  const p = pop(t, start);
  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: 1920, height: 1080, opacity: fadeOut(t, end), transform: `scale(${p})`, transformOrigin: `${tx}px ${ty}px`}}>
      <div style={{position: 'absolute', left: x - 170, top: y - 125, width: 340, height: 250, borderRadius: '50%', background: '#fff', border: `5px solid ${O}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{children}</div>
      {[[0.2, 34], [0.5, 24], [0.78, 16]].map(([r, d]) => (
        <div key={r} style={{position: 'absolute', left: x + (tx - x) * r - d / 2, top: y + 125 + (ty - y - 125) * r - d / 2, width: d, height: d, borderRadius: '50%', background: '#fff', border: `4px solid ${O}`}} />
      ))}
    </div>
  );
};

// নিচের ভাসমান ক্যাপশন (শুধু ন্যারেশনে, বাবল/কার্ড না থাকলে)
export const Caption: React.FC<{t: number}> = ({t}) => {
  const c = CAPS.find((c) => t >= c.s && t < c.e);
  if (!c || textBusy(t)) return null;
  const p = pop(t, c.s, 14);
  const o = interpolate(t, [c.e - 0.1, c.e], [1, 0], clamp);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 70, textAlign: 'center', opacity: Math.min(1, p) * o, transform: `translateY(${(1 - Math.min(1, p)) * 36}px)`, fontSize: 70, fontWeight: 700, color: '#fff', whiteSpace: 'nowrap', WebkitTextStroke: '11px #222', paintOrder: 'stroke fill', letterSpacing: 1}}>
      {c.t.split(' ').map((w, i) => (
        <span key={i} style={{color: isHl(w, c.h) ? '#FFD23F' : '#fff'}}>{w}{' '}</span>
      ))}
    </div>
  );
};
