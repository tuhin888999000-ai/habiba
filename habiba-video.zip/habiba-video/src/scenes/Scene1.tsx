import React from 'react';
import {Bubble, FloatIcon, Pill, SceneFx, useScene} from '../components/UI';
import {BedBack, BedFront, Room, Win, bedTop} from '../components/Props';
import {Character, HeadOnly} from '../components/Character';
import {B, SC, isTalking, sec} from '../data';

// দৃশ্য ১: সকালের ঘটনা (০:০০ – ০:১৬)
export const Scene1: React.FC = () => {
  const {f, t} = useScene(SC.s1[0]);
  const dur = sec(SC.s1[1] - SC.s1[0]);
  const FY = 900;
  const top = bedTop(FY);
  const up = t >= 14.2;
  const wave = Math.sin(f / 5) * 6;
  const aL = t >= 5 && t < 9.6 ? 60 + wave : t >= 12.7 ? 75 + wave : 10;
  return (
    <SceneFx dur={dur}>
      <Room wall="#FFEFD0" floor="#D9A66B" floorY={800}>
        <Win x={560} y={120} w={420} h={336} />
        <BedBack x={120} floorY={FY} w={950} />
        {!up && <HeadOnly who="habiba" expr={t < 9.68 ? 'sleepy' : 'tired'} talking={isTalking('habiba', t)} x={290} y={top - 70} w={360} rot={-6} />}
        {up && <Character who="habiba" outfit="home" expr="tired" x={290} floorY={top + 5 + 187} scale={1.1} aL={t < 15.6 ? 140 : 15} aR={t < 15.6 ? 140 : 15} />}
        <BedFront x={120} floorY={FY} w={950} bx={up ? 200 : 400} lift={up ? 0 : 40} color="#F4A6C0" />
        <Character who="ammu" expr={t >= 12.7 ? 'worried' : 'happy'} talking={isTalking('ammu', t)} x={1290} floorY={FY} scale={1.45} aL={aL} />
        <FloatIcon name="zzz" x={480} y={380} size={130} t={t} start={0.4} end={5.6} anim="float" />
        <Pill text="গ্রামের একটি ঘর · সকাল" t={t} start={0.3} end={4.6} top={60} left={60} />
        <Pill text="হাবিবা" cx={290} top={415} t={t} start={0.9} end={2.8} bg="#FF6FA5" size={34} />
        <Pill text="আম্মু" cx={1290} top={205} t={t} start={3.66} end={4.9} bg="#2E9E5B" size={34} />
        <Bubble b={B.wake} t={t} x={1060} y={265} w={760} tail={230} />
        <Bubble b={B.sleep} t={t} x={430} y={470} w={640} tail={-140} />
        <Bubble b={B.late} t={t} x={1060} y={265} w={760} tail={230} />
      </Room>
    </SceneFx>
  );
};
