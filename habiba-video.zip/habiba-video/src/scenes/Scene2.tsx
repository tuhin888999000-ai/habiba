import React from 'react';
import {FloatIcon, Icon, Pill, SceneFx, Thought, useScene} from '../components/UI';
import {Room} from '../components/Props';
import {Character, Expr} from '../components/Character';
import {SC, sec} from '../data';

const O = '#222222';

// দৃশ্য ২: রাগ করে স্কুলে যাওয়া (০:১৬ – ০:২৩)
export const Scene2: React.FC = () => {
  const {f, t} = useScene(SC.s2[0]);
  const dur = sec(SC.s2[1] - SC.s2[0]);
  const wt = t - 20.9;
  const walking = wt > 0;
  const hx = walking ? 1400 + wt * 380 : 1400;
  const walk = f / 2.6;
  const sw = Math.sin(walk) * 25;
  const hExpr: Expr = t < 18.0 ? 'happy' : t < 19.0 ? 'sad' : 'angry';
  const shake = t > 19.2 && t < 19.9 ? 6 : 0;
  const wave = Math.sin(f / 6) * 6;
  return (
    <SceneFx dur={dur} shake={shake}>
      <Room wall="#FFE0BD" floor="#C58B5A" floorY={800}>
        {/* মাটির চুলা ও হাঁড়ি */}
        <svg style={{position: 'absolute', left: 60, top: 480}} width={360} height={330} viewBox="0 0 360 330">
          <path d="M30,320 L60,150 L300,150 L330,320 Z" fill="#8D5A3B" stroke={O} strokeWidth={5} strokeLinejoin="round" />
          <ellipse cx={180} cy={150} rx={125} ry={22} fill="#6B4228" stroke={O} strokeWidth={5} />
          <path d="M90,150 Q90,70 180,70 Q270,70 270,150Z" fill="#9AA5B1" stroke={O} strokeWidth={5} />
          <rect x={160} y={52} width={40} height={18} rx={6} fill="#6C7683" stroke={O} strokeWidth={4} />
          <path d="M130,320 Q130,230 180,230 Q230,230 230,320Z" fill="#2B1A10" />
          <path d="M150,320 Q180,246 210,320Z" fill="#FF9F1C" />
          {[0, 1, 2].map((i) => {
            const p = ((f * 1.2 + i * 30) % 90) / 90;
            return <circle key={i} cx={180 + Math.sin(f / 8 + i) * 12} cy={40 - p * 80} r={14 + p * 8} fill="#fff" opacity={0.7 * (1 - p)} />;
          })}
        </svg>
        {/* টেবিল ও খাবার */}
        <svg style={{position: 'absolute', left: 760, top: 640}} width={420} height={260} viewBox="0 0 420 260">
          <g stroke={O} strokeWidth={5} strokeLinejoin="round">
            <rect x={30} y={90} width={26} height={170} fill="#8A5530" />
            <rect x={364} y={90} width={26} height={170} fill="#8A5530" />
            <rect x={0} y={60} width={420} height={30} rx={8} fill="#A5683D" />
            <ellipse cx={210} cy={52} rx={110} ry={22} fill="#fff" />
            <path d="M150,50 Q180,0 215,50Z" fill="#fff" />
            <ellipse cx={252} cy={46} rx={36} ry={14} fill="#E9742B" />
          </g>
          {[0, 1].map((i) => {
            const p = ((f * 1.1 + i * 40) % 80) / 80;
            return <circle key={i} cx={205 + Math.sin(f / 7 + i * 2) * 10} cy={-4 - p * 70} r={12 + p * 8} fill="#fff" opacity={0.75 * (1 - p)} />;
          })}
        </svg>
        <Character who="ammu" expr={t < 20.3 ? 'happy' : 'sad'} x={560} floorY={900} scale={1.45} aR={t < 20.3 ? 65 + wave : 10} />
        <Character
          who="habiba" outfit="school" expr={hExpr} x={hx} floorY={900} scale={1.1}
          tremble={!walking && t >= 19 ? 2.5 : 0}
          walk={walking ? walk : undefined}
          aL={walking ? 10 + sw : 10} aR={walking ? 10 - sw : 10}
        />
        <Thought x={1230} y={290} tx={1360} ty={440} t={t} start={17.9} end={20.3}>
          <Icon name="burger" size={170} />
        </Thought>
        <FloatIcon name="anger" x={1500} y={400} size={130} t={t} start={19.1} end={21.0} anim="shake" />
        <FloatIcon name="tear" x={650} y={450} size={60} t={t} start={21.5} end={23.6} anim="float" />
        <Pill text="নাস্তার টেবিল" t={t} start={16.7} end={20.0} top={60} left={60} />
      </Room>
    </SceneFx>
  );
};
