import React from 'react';
import {Bubble, FloatIcon, Pill, SceneFx, useScene} from '../components/UI';
import {BedBack, BedFront, Room, Win, bedTop} from '../components/Props';
import {Character, Expr, HeadOnly} from '../components/Character';
import {B, SC, isTalking, sec} from '../data';

// দৃশ্য ৩: হাবিবার উপলব্ধি (০:২৩ – ০:৪১)
export const Scene3: React.FC = () => {
  const {f, t} = useScene(SC.s3[0]);
  const dur = sec(SC.s3[1] - SC.s3[0]);
  const FY = 900;
  const top = bedTop(FY);
  const enter = Math.min(1, Math.max(0, (t - 23.9) / 2.3));
  const sit = Math.min(1, Math.max(0, (t - 34.5) / 0.45));
  const e = 1 - Math.pow(1 - sit, 3);
  const hx = 2100 - 650 * enter - 300 * e;
  const hy = FY - 38 * e;
  const walking = t >= 23.9 && enter < 1;
  const sw = Math.sin(f / 2.6) * 25;
  const hExpr: Expr = t < 25.2 ? 'happy' : t < 34.5 ? 'worried' : 'cry';
  const shake = t > 40.44 ? 3.5 : 0;
  return (
    <SceneFx dur={dur} zoom={[1, 1.1]} origin="55% 60%" shake={shake}>
      <Room wall="#F6D7B0" floor="#B98250" floorY={800}>
        <Win x={680} y={120} w={420} h={336} dusk />
        <BedBack x={300} floorY={FY} w={1000} />
        <HeadOnly who="ammu" hair="loose" expr="tired" talking={isTalking('ammu', t)} x={470} y={top - 72} w={380} rot={-8} />
        <Character
          who="habiba" outfit="school" expr={hExpr} x={hx} floorY={hy} scale={1.1}
          tremble={t >= 34.5 ? 2.5 : 0}
          walk={walking ? f / 2.6 : undefined}
          aL={walking ? 10 + sw : 10} aR={walking ? 10 - sw : 10}
        />
        <BedFront x={300} floorY={FY} w={1000} bx={570} lift={40} color="#9DB8D9" />
        <FloatIcon name="thermo" x={760} y={540} size={120} t={t} start={25.6} end={28.7} anim="pulse" />
        <Pill text="স্কুল থেকে ফেরার পর" t={t} start={23.8} end={27.0} top={60} left={60} />
        <Bubble b={B.ok1} t={t} x={520} y={470} w={700} tail={-50} />
        <Bubble b={B.what} t={t} x={1230} y={410} w={620} tail={220} />
        <Bubble b={B.ok2} t={t} x={520} y={470} w={700} tail={-50} />
      </Room>
    </SceneFx>
  );
};
