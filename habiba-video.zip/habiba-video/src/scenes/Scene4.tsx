import React from 'react';
import {Bubble, FloatIcon, SceneFx, useScene} from '../components/UI';
import {BedBack, BedFront, Room, Win, bedTop} from '../components/Props';
import {Character, Expr} from '../components/Character';
import {B, SC, isTalking, sec} from '../data';

// দৃশ্য ৪: সুন্দর শিক্ষা — মাফ চাওয়া ও জড়িয়ে ধরা (০:৪১ – ০:৫৩)
export const Scene4: React.FC = () => {
  const {f, t} = useScene(SC.s4[0]);
  const dur = sec(SC.s4[1] - SC.s4[0]);
  const FY = 900;
  const top = bedTop(FY);
  const mv = Math.min(1, Math.max(0, (t - 50.8) / 0.8));
  const e = mv * mv * (3 - 2 * mv);
  const hx = 1100 - 370 * e;
  const hug = t >= 51.3;
  const hExpr: Expr = t < 47.94 ? 'cry' : 'smile';
  const aExpr: Expr = t < 47.94 ? 'tired' : 'smile';
  const wave = Math.sin(f / 6) * 4;
  return (
    <SceneFx dur={dur} zoom={[1, 1.12]} origin="50% 60%">
      <Room wall="#F6D7B0" floor="#B98250" floorY={800}>
        <Win x={680} y={120} w={420} h={336} dusk />
        <BedBack x={300} floorY={FY} w={1000} />
        <Character
          who="ammu" hair="loose" expr={aExpr} talking={isTalking('ammu', t)} x={560}
          floorY={top + 5 + 230} scale={1.35}
          aL={hug ? -25 : 12} aR={hug ? 70 : t >= 47.94 ? 40 + wave : 12}
        />
        <BedFront x={300} floorY={FY} w={1000} bx={380} color="#9DB8D9" />
        <Character
          who="habiba" outfit="school" expr={hExpr} talking={isTalking('habiba', t)} x={hx} floorY={940} scale={1.1}
          tremble={t < 47.94 ? 2 : 0} aL={hug ? 75 : 10} aR={hug ? 40 : 10}
        />
        <FloatIcon name="heart" x={640} y={250} size={110} t={t} start={51.2} end={53.12} anim="float" />
        <FloatIcon name="heart" x={880} y={330} size={90} t={t} start={51.5} end={53.12} anim="float" />
        <FloatIcon name="heart" x={500} y={220} size={80} t={t} start={51.8} end={53.12} anim="float" />
        <Bubble b={B.sorry1} t={t} x={1000} y={450} w={680} tail={100} />
        <Bubble b={B.sorry2} t={t} x={1000} y={450} w={680} tail={100} />
        <Bubble b={B.happy} t={t} x={620} y={300} w={700} tail={-60} />
      </Room>
    </SceneFx>
  );
};
