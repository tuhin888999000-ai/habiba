import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Icon, IconName, SceneFx, clamp, fadeOut, isHl, pop, useScene} from '../components/UI';
import {SC, sec} from '../data';

const O = '#222222';

// প্রতিটি কার্ডের সময় (ন্যারেশন অনুযায়ী)
const T = {c1: [53.12, 56.34], c2: [56.34, 59.0], c3: [59.0, 61.0], c4: [61.0, 65.0], c5: [65.0, 67.4], c6: [67.4, 72]};

const Win: React.FC<{t: number; range: number[]; children: React.ReactNode}> = ({t, range, children}) => {
  if (t < range[0] - 0.02 || t > range[1]) return null;
  const o = Math.min(interpolate(t, [range[0], range[0] + 0.2], [0, 1], clamp), range[1] >= 72 ? 1 : fadeOut(t, range[1]));
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};

const Area: React.FC<{children: React.ReactNode; top?: number; h?: number}> = ({children, top = 60, h = 560}) => (
  <div style={{position: 'absolute', left: 0, right: 0, top, height: h, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 60}}>{children}</div>
);

const Quote: React.FC<{text: string; hl: string; t: number; s: number}> = ({text, hl, t, s}) => (
  <div style={{position: 'absolute', left: 200, right: 200, top: 660, transform: `scale(${pop(t, s + 0.15, 13)})`, background: '#fff', border: `6px solid ${O}`, borderRadius: 48, padding: '34px 50px', textAlign: 'center', fontSize: 78, fontWeight: 700, lineHeight: 1.25, color: O, boxShadow: '0 12px 0 rgba(0,0,0,.18)'}}>
    {text.split(' ').map((w, i) => (
      <span key={i} style={{color: isHl(w, hl) ? '#E63946' : O}}>{w}{' '}</span>
    ))}
  </div>
);

const BigIcon: React.FC<{name: IconName; size: number; t: number; s: number; pulse?: boolean}> = ({name, size, t, s, pulse}) => {
  const f = useCurrentFrame();
  return (
    <div style={{transform: `scale(${pop(t, s) * (pulse ? 1 + 0.07 * Math.sin(f / 5) : 1)})`}}>
      <Icon name={name} size={size} />
    </div>
  );
};

// দাঁড়িপাল্লা: ভালোবাসার দিক ভারী
const Scale: React.FC<{t: number; s: number}> = ({t, s}) => {
  const a = -14 * Math.min(1, Math.max(0, (t - s - 0.2) / 1.0));
  const r = (a * Math.PI) / 180;
  const L = 250, cx = 400, cy = 130;
  const lx = cx - L * Math.cos(r), ly = cy - L * Math.sin(r);
  const rx = cx + L * Math.cos(r), ry = cy + L * Math.sin(r);
  const pan = (px: number, py: number) => `M${px - 95},${py + 170} Q${px},${py + 240} ${px + 95},${py + 170} Z`;
  return (
    <svg width={800} height={520} viewBox="0 0 800 520" style={{transform: `scale(${pop(t, s)})`}}>
      <g stroke={O} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round">
        <path d="M300,500 L500,500 L400,130 Z" fill="#C9A227" />
        <line x1={lx} y1={ly} x2={rx} y2={ry} stroke={O} strokeWidth={14} />
        <circle cx={cx} cy={cy} r={16} fill="#FFC93C" />
        {[[lx, ly], [rx, ry]].map(([px, py], i) => (
          <g key={i}>
            <line x1={px} y1={py} x2={px - 80} y2={py + 170} strokeWidth={4} />
            <line x1={px} y1={py} x2={px + 80} y2={py + 170} strokeWidth={4} />
            <path d={pan(px, py)} fill="#E0B84A" />
          </g>
        ))}
      </g>
      <g transform={`translate(${lx - 60},${ly + 60})`}><Icon name="heart" size={120} /></g>
      <g transform={`translate(${rx - 70},${ry + 118})`}><Icon name="coin" size={52} /></g>
      <g transform={`translate(${rx - 12},${ry + 118})`}><Icon name="coin" size={52} /></g>
      <g transform={`translate(${rx - 42},${ry + 80})`}><Icon name="coin" size={52} /></g>
    </svg>
  );
};

const Globe: React.FC = () => (
  <svg width={420} height={420} viewBox="0 0 420 420">
    <circle cx={210} cy={210} r={190} fill="#4FB3FF" stroke={O} strokeWidth={7} />
    <path d="M110,150 Q150,90 220,120 Q250,160 200,200 Q150,230 110,190Z" fill="#6CC24A" stroke={O} strokeWidth={5} />
    <path d="M250,240 Q320,230 340,290 Q320,350 260,330 Q230,290 250,240Z" fill="#6CC24A" stroke={O} strokeWidth={5} />
  </svg>
);

export const Scene5: React.FC = () => {
  const {f, t} = useScene(SC.s5[0]);
  const dur = sec(SC.s5[1] - SC.s5[0]);
  const spin = ((t - T.c5[0]) * 540);
  return (
    <SceneFx dur={dur}>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 38%, #FFF6EA 0%, #FFD9D2 100%)'}}>
        {[...Array(8)].map((_, i) => {
          const y = 1180 - ((f * 1.3 + i * 170) % 1300);
          return (
            <div key={i} style={{position: 'absolute', left: 120 + i * 230 + Math.sin(f / 30 + i) * 30, top: y, opacity: 0.18}}>
              <Icon name="heart" size={60 + (i % 3) * 25} />
            </div>
          );
        })}

        {/* ১. মা আমাদের জীবনের সবচেয়ে বড় আশীর্বাদ */}
        <Win t={t} range={T.c1}>
          <Area>
            <BigIcon name="star" size={140} t={t} s={T.c1[0] + 0.3} />
            <BigIcon name="heart" size={400} t={t} s={T.c1[0]} pulse />
            <BigIcon name="star" size={140} t={t} s={T.c1[0] + 0.5} />
          </Area>
          <Quote text="মা আমাদের জীবনের সবচেয়ে বড় আশীর্বাদ" hl="আশীর্বাদ" t={t} s={T.c1[0]} />
        </Win>

        {/* ২. মায়ের ভালোবাসার কোনো মূল্য হয় না */}
        <Win t={t} range={T.c2}>
          <Area top={80} h={540}><Scale t={t} s={T.c2[0]} /></Area>
          <Quote text="মায়ের ভালোবাসার কোনো মূল্য হয় না" hl="ভালোবাসার" t={t} s={T.c2[0]} />
        </Win>

        {/* ৩. কখনো মায়ের মনে কষ্ট দিও না */}
        <Win t={t} range={T.c3}>
          <Area>
            <div style={{transform: `rotate(${Math.sin(f * 1.1) * 4}deg)`}}>
              <BigIcon name="brokenHeart" size={400} t={t} s={T.c3[0]} />
            </div>
          </Area>
          <Quote text="তাই কখনো মায়ের মনে কষ্ট দিও না" hl="কষ্ট" t={t} s={T.c3[0]} />
        </Win>

        {/* ৪. ভালোবাসো, সম্মান করো, যত্ন নাও — তিনটি আইকন-কার্ড */}
        <Win t={t} range={T.c4}>
          <Area top={190} h={600}>
            {([['heart', 'মাকে ভালোবাসো', 61.1], ['crown', 'সম্মান করো', 62.4], ['cross', 'যত্ন নাও', 63.7]] as [IconName, string, number][]).map(([ic, label, s]) => (
              <div key={label} style={{width: 470, height: 520, background: '#fff', border: `6px solid ${O}`, borderRadius: 48, boxShadow: '0 12px 0 rgba(0,0,0,.18)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 30, transform: `scale(${pop(t, s, 13)})`}}>
                <BigIcon name={ic} size={240} t={t} s={s + 0.1} pulse />
                <div style={{fontSize: 64, fontWeight: 700, color: O}}>{label}</div>
              </div>
            ))}
          </Area>
        </Win>

        {/* ৫. মা বেঁচে থাকতে মায়ের মূল্য বোঝো */}
        <Win t={t} range={T.c5}>
          <Area>
            <Icon name="clock" size={300} rot={spin} />
            <div style={{fontSize: 200, fontWeight: 700, color: '#FF7A45', transform: `translateX(${Math.sin(f / 4) * 12}px)`}}>→</div>
            <BigIcon name="heart" size={300} t={t} s={T.c5[0] + 0.3} pulse />
          </Area>
          <Quote text="মা বেঁচে থাকতে মায়ের মূল্য বোঝো" hl="বেঁচে" t={t} s={T.c5[0]} />
        </Win>

        {/* ৬. মায়ের ভালোবাসার মতো ভালোবাসা পৃথিবীতে আর নেই */}
        <Win t={t} range={T.c6}>
          <Area>
            <div style={{transform: `scale(${pop(t, T.c6[0])})`}}><Globe /></div>
            <BigIcon name="heart" size={280} t={t} s={T.c6[0] + 0.3} pulse />
          </Area>
          <Quote text="মায়ের ভালোবাসার মতো ভালোবাসা পৃথিবীতে আর নেই" hl="পৃথিবীতে" t={t} s={T.c6[0]} />
          {t > 70.8 && (
            <div style={{position: 'absolute', left: 0, right: 0, bottom: 50, textAlign: 'center', fontSize: 40, fontWeight: 600, color: '#B5485D', opacity: interpolate(t, [70.8, 71.3], [0, 1], clamp)}}>
              হাবিবা ও তার আম্মুর ভালোবাসা
            </div>
          )}
        </Win>
      </AbsoluteFill>
    </SceneFx>
  );
};
